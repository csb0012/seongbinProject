package com.springboot.react.service;

import com.springboot.react.entity.Contect;

public interface ContectService {
	Contect saveContect(Contect contect); // 문의사항 등록 메소드
}

