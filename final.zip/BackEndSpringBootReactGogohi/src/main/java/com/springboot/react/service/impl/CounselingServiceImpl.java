package com.springboot.react.service.impl;

import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.springboot.react.entity.Counseling_mjh;
import com.springboot.react.repository.Counseling_mjhRepository;
import com.springboot.react.service.CounselingService;

@Service
public class CounselingServiceImpl implements CounselingService{

	private final Counseling_mjhRepository counseling_mjhRepository;
		
	@Autowired
	public CounselingServiceImpl(Counseling_mjhRepository counseling_mjhRepository) {
		this.counseling_mjhRepository = counseling_mjhRepository;
	}
	
	// 게시글 저장 메소드 구현
	@Override
	@Transactional
	public Counseling_mjh saveCounseling_mjh(Counseling_mjh counseling_mjh) {
		return counseling_mjhRepository.save(counseling_mjh);
	}
	
	// Pageable 객체를 매개변수로 받아 페이징 처리된 Counseling_mjh 목록을 반환합니다
	@Override
	public Page<Counseling_mjh> findAll(Pageable pageable) {
		return counseling_mjhRepository.findAll(pageable);
	}
	
	// 검색 기능을 추가한 findAllBySearch 메서드입니다.
		@Override
		public Page<Counseling_mjh> findAllBySearch(String search, Pageable pageable) {
			// 검색어가 제공된 경우 해당 검색어를 포함하는 게시글을 조회합니다.
			if (search != null && !search.trim().isEmpty()) {
				return counseling_mjhRepository.findByCounselingTitleContainingOrCounselingContentsContainingOrCounselingWriterContaining(search, search, search, pageable);
			}else {
				return counseling_mjhRepository.findAll(pageable);
			}
		}
	@Override
	public Optional<Counseling_mjh> findById(Long id) {
		return null;
	}
	
	// ID를 통한 게시글 조회 메소드 구현
	@Override
	public Optional<Counseling_mjh> findCounseling_mjhById(Long id) {
		return counseling_mjhRepository.findById(id);
	}
	
	// 수정 메소드 구현
	@Override
	public Counseling_mjh updateCounseling_mjh(Long id, Counseling_mjh counseling_mjhDetails) {
		Counseling_mjh counseling_mjh = counseling_mjhRepository.findById(id).orElseThrow(()-> new RuntimeException("Counseling_mjh not found with id" + id));
		counseling_mjh.setCounselingTitle(counseling_mjhDetails.getCounselingTitle());
		counseling_mjh.setCounselingContents(counseling_mjhDetails.getCounselingContents());
		Counseling_mjh updateCounseling_mjh = counseling_mjhRepository.save(counseling_mjh);
		return updateCounseling_mjh;
	}
	
	// 게시글 삭제 메소드 구현
	@Override
	@Transactional
	public void deleteCounseling_mjh(Long id) {
		counseling_mjhRepository.deleteById(id);
	}

	
	
	
}
