package com.springboot.react.service;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.springboot.react.entity.Counseling_mjh;

public interface CounselingService {
	// 게시글 저장 메소드
	// 파라미터: Counseling_mjh 객체
    // 반환: 저장된 Counseling_mjh 객체
    // 설명: 이 메소드는 주어진 Counseling_mjh 객체를 데이터베이스에 저장하고 저장된 객체를 반환합니다.
	Counseling_mjh saveCounseling_mjh(Counseling_mjh counseling_mjh);
	
	// 페이징 처리를 위해 수정된 findAll 메서드
	Page<Counseling_mjh> findAll(Pageable pageable);

	// 상담글 상세 조회 메서드 선언
    Optional<Counseling_mjh> findById(Long id);
    
    // ID를 기준으로 게시글 검색 메소드
    Optional<Counseling_mjh> findCounseling_mjhById(Long id);
    
    // 검색어에 따라 필터링된 상담글 목록을 조회하는 메서드
    Page<Counseling_mjh> findAllBySearch(String search, Pageable pageable);
    
    // 게시글 수정 메서드 선언
    Counseling_mjh updateCounseling_mjh(Long id, Counseling_mjh counseling_mjhDetails);
    
    // 게시글 삭제 메서드 선언
    void deleteCounseling_mjh(Long id);
}

