package com.springboot.react.service.impl;

import com.springboot.react.model.Address;
import com.springboot.react.repository.AddressRepository;
import com.springboot.react.service.AddressService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class AddressServiceImpl implements AddressService {

    // PaymentRepository 인스턴스를 자동 주입받아 사용
    @Autowired
    private AddressRepository addressRepository;

    @Override
    public void insertAddressSuccess(Address address) {
        // 주소 정보를 로그에 출력하여 저장 시도를 확인
        System.out.println("주소 정보 저장 시도: " + address);

        // Address 객체를 데이터베이스에 저장
        addressRepository.save(address);

        // 저장 성공 메시지를 로그에 출력
        System.out.println("주소 정보 저장 성공");
    }
}
