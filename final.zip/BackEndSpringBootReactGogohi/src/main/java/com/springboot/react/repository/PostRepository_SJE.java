package com.springboot.react.repository;

import com.springboot.react.entity.Post_SJE;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
// import org.springframework.data.jpa.repository.Query;

public interface PostRepository_SJE extends JpaRepository<Post_SJE, Long>  {
	Page<Post_SJE> findAll(Pageable pageable);

    Page<Post_SJE> findByBoardTitleContainingOrBoardContentsContainingOrBoardWriterContaining(String boardTitle, String boardContents, String boardWriter, Pageable pageable);
    
}
