package com.springboot.react.model;

import javax.persistence.*;

import lombok.Data;

@Data // Lombok 라이브러리를 사용하여 getter, setter, toString 등의 메소드를 자동으로 생성
@Entity // JPA 엔티티임을 나타냄
@Table(name = "react_address") // 엔티티와 매핑할 테이블 이름을 지정
public class Address {
    @Id // 기본 키(primary key)임을 나타냄
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "address_seq_gen") // 시퀀스를 사용하여 기본 키 값을 자동으로 생성
    @SequenceGenerator(name = "address_seq_gen", sequenceName = "idx_seq", allocationSize = 1) // 시퀀스 제너레이터 설정, 시퀀스 이름과 할당 크기 설정
    private Long id; 

    private String mainAddress;  // 기본 주소 필드 선언
    private String subAddress;   // 상세 주소 필드 선언

}