// 패키지 선언
package com.springboot.react.entity;

import java.time.LocalDate;
import java.util.Date;

//JPA 및 관련 어노테이션 import
import javax.persistence.*;

//Lombok 라이브러리를 이용한 코드 단순화 어노테이션
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "notices_mjh")
public class Notice_mjh {
	
	// 공지글의 고유 번호 (ID)
    @Id // 이 필드를 테이블의 기본 키로 설정
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "notice_seq") // ID 값을 자동으로 생성하며, 시퀀스를 사용
    @SequenceGenerator(name = "notice_seq", sequenceName = "NOTICE_SEQ", allocationSize = 1) // 시퀀스 생성기 정의
    private Long noticeNumber; // 공지글 번호
    
    // 공지글 제목
    @Column(nullable = false) // 이 필드는 데이터베이스에 null을 허용하지 않음
    private String noticeTitle; // 공지글 제목

    // 공지글 내용
    @Column(nullable = false, length = 1000) // 이 필드는 데이터베이스에 null을 허용하지 않음
    private String noticeContents; // 공지글 내용

    // 공지글 작성자
    @Column(nullable = false) // 이 필드는 데이터베이스에 null을 허용하지 않음
    private String noticeWriter; // 공지글 작성자 이름
    
    // 공지글 작성일자
    @Column(nullable = true) // 이 필드는 데이터베이스에 null을 허용하지 않음
    private Date noticeDate; // 공지글 작성일자

	@Column(nullable = true)
	private String imagePath;
}
