package com.springboot.react.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "school_data")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SchoolData {
	
	
    
	@Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "school_data_seq")
    @SequenceGenerator(name = "school_data_seq", sequenceName = "school_data_SEQ", allocationSize = 1)
    private Long id; // 구분 ID 번호

    @Column(name = "FOUND_DIV_NM", length = 50)
    private String foundDivNm; // 학교 구분(공립/사립)

    @Column(name = "FACLT_NM", length = 100)
    private String facltNm; // 학교 이름

    @Column(name = "TELNO", length = 20)
    private String telno; // 전화번호

    @Column(name = "REFINE_LOTNO_ADDR", length = 1000)
    private String refineLotnoAddr; // 지번 주소

    @Column(name = "REFINE_ROADNM_ADDR", length = 1000)
    private String refineRoadnmAddr; // 도로명 주소

    @Column(name = "REFINE_ZIP_CD", length = 1000)
    private String refineZipCd; // 우편번호

    @Column(name = "OCR_RANK")
    private Integer ocrRank; // OCR 내신등급

    @Column(name = "SCHOOL_DIV_NM", length = 50)
    private String schoolDivNm; // 학교구분명

    @Column(name = "SCHOOL_CLASSIFICATION", length = 100)
    private String schoolClassification; // 고등학교 구분명

    @Column(name = "OPENAPI_RANK")
    private Integer openApiRank; // OPENAPI 내신등급

    
}