package com.springboot.react.service;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.springboot.react.entity.Post_SJE;

public interface PostService_SJE {

    // Post_SJE 객체를 저장하는 메서드
    Post_SJE savePost(Post_SJE post);

    // 주어진 ID로 Post_SJE 객체를 조회하는 메서드
    Optional<Post_SJE> findById(Long id);
    
    // 게시글 수정 메서드 선언
    Post_SJE updatePost(Long id, Post_SJE postDetails);
    
    // 모든 Post_SJE 객체를 페이지별로 조회하는 메서드
    Page<Post_SJE> findAll(Pageable pageable);

    // 검색어를 기반으로 Post_SJE 객체를 페이지별로 조회하는 메서드
    Page<Post_SJE> findAllBySearch(String search, Pageable pageable);
    
    // 주어진 ID로 Post_SJE 객체를 삭제하는 메서드
    void deletePost(Long id);
    
}
