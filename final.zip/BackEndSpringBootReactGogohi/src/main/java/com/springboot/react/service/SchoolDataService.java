package com.springboot.react.service;

import com.springboot.react.entity.SchoolData;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Optional;

public interface SchoolDataService {
    Page<SchoolData> findAll(Pageable pageable);
    Page<SchoolData> findByOpenApiRank(Integer rank, Pageable pageable);
    Optional<SchoolData> findById(Long id);
    SchoolData saveData(SchoolData data);
}
