package com.springboot.react;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackEndSpringBootReactGogohiApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackEndSpringBootReactGogohiApplication.class, args);
		System.out.println("연결 확인");
	}

}
