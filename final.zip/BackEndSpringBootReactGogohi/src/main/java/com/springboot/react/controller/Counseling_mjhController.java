package com.springboot.react.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.react.entity.Counseling_mjh;
import com.springboot.react.service.CounselingService;

import lombok.extern.log4j.Log4j;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//클래스 선언 및 REST 컨트롤러 어노테이션, 기본 경로 설정
@RestController
@RequestMapping("/api/counseling_mjh")
public class Counseling_mjhController {
	
	private static final Logger logger = LoggerFactory.getLogger(Counseling_mjhController.class);
	
	private final CounselingService counselingService;
	
	// 자동으로 counselingService의 인스턴스 의존성 주입
	@Autowired
	public Counseling_mjhController(CounselingService counselingService) {
       this.counselingService = counselingService;
    }
	
	// @PostMapping은 HTTP POST 요청을 처리하는 메소드임을 나타내는 어노테이션입니다.
	// 메소드 위에 별도의 경로를 지정하지 않았기 때문에, 클래스 레벨의 @RequestMapping의 경로를 사용합니다.
	 @PostMapping
	 public Counseling_mjh createCounseling_mjh(@RequestBody Counseling_mjh counseling_mjh) {
//		 System.out.println("Received counseling: " + counseling_mjh);
	     // @RequestBody 어노테이션은 HTTP 요청의 본문을 Java 객체로 매핑합니다.
	     // 이 메소드는 클라이언트로부터 받은 객체를 Service를 통해 저장하고,
	     // 저장된  객체를 반환합니다.
	    return counselingService.saveCounseling_mjh(counseling_mjh);
	}
	 
	// 페이징 처리를 추가한 게시글 목록 조회 메서드
    // @RequestParam은 URL의 쿼리 파라미터를 메소드의 파라미터로 매핑합니다.
    // 기본값으로 page는 0, size는 3으로 설정됩니다.
	@GetMapping("/list")
	public ResponseEntity<Page<Counseling_mjh>> getAllCounselingPosts_mjh(@RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "5") int size, @RequestParam(required = false)String search){
		Pageable pageable = PageRequest.of(page, size);
		Page<Counseling_mjh> counselingPosts_mjh;
		if (search != null && !search.trim().isEmpty()) { counselingPosts_mjh = counselingService.findAllBySearch(search, pageable); 
		}else {
			counselingPosts_mjh = counselingService.findAll(pageable);
		}
		return ResponseEntity.ok(counselingPosts_mjh);
	}
	
	// 특정 아이디로 게시글 조회
		@GetMapping("/{id}")
		public ResponseEntity<Counseling_mjh> getCounseling_mjhById(@PathVariable Long id){
			Optional<Counseling_mjh> counseling_mjh = counselingService.findCounseling_mjhById(id);
			return ResponseEntity.ok(counseling_mjh.get()); 
		}
		// 글 수정 메서드
	@PutMapping("/{id}")
	public ResponseEntity<Counseling_mjh> updateCounseling_mjh(@PathVariable Long id, @RequestBody Counseling_mjh counseling_mjhDetails){
		Counseling_mjh updateCounseling_mjh = counselingService.updateCounseling_mjh(id, counseling_mjhDetails);
	
		return ResponseEntity.ok().build();
	}
	
//	// 글 삭제 메서드
//	@DeleteMapping("/{id}")
//	public ResponseEntity<?> deleteCounseling_mjh(@PathVariable Long id) {
//		counselingService.deleteCounseling_mjh(id);
//		return ResponseEntity.ok().build();
//	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<?> deleteCounseling_mjh(@PathVariable Long id) {
	    System.out.println("삭제 요청 ID: " + id);  // 로그 추가
	    try {
	        counselingService.deleteCounseling_mjh(id);
	        logger.info("상담글 삭제 성공, ID: " + id);
	        return ResponseEntity.ok().build();
	    } catch (Exception e) {
	        System.err.println("삭제 중 오류 발생: " + e.getMessage());  // 오류 로그
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("삭제 실패");
	    }
	}

}