package com.springboot.react.entity;

import java.util.Date;

//필요한 JPA와 Lombok 라이브러리 클래스를 임포트합니다.
import javax.persistence.*;
import lombok.*;

@Entity
@Table(name = "posts_sje")
@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
public class Post_SJE {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "post_seq")
	@SequenceGenerator(name = "post_seq", sequenceName = "POST_SEQ", allocationSize = 1)
	private Long boardNumber;
	
	@Column(nullable = false)
	private String boardTitle;
	
	@Column(nullable = false)
	private String boardContents;
	
	@Column(nullable = false)
	private String boardWriter;
	
}
