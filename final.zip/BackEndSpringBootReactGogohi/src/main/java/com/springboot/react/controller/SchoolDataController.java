package com.springboot.react.controller;

import com.springboot.react.entity.SchoolData;
import com.springboot.react.service.SchoolDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/schools")
public class SchoolDataController {

    private final SchoolDataService schoolDataService;

    @Autowired
    public SchoolDataController(SchoolDataService schoolDataService) {
        this.schoolDataService = schoolDataService;
    }

    // 페이징 및 랭크 검색 기능 추가
    @GetMapping
    public ResponseEntity<Page<SchoolData>> getAllSchools(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(required = false) Integer rank) {

        Pageable pageable = PageRequest.of(page, size);
        Page<SchoolData> schoolDataPage;

        // 랭크가 있을 경우 해당 랭크로 필터링, 없으면 전체 조회
        if (rank != null) {
            schoolDataPage = schoolDataService.findByOpenApiRank(rank, pageable);
        } else {
            schoolDataPage = schoolDataService.findAll(pageable);
        }

        return ResponseEntity.ok(schoolDataPage);
    }
}
