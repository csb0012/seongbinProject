package com.springboot.react.repository;

import com.springboot.react.model.Address;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository // 이 인터페이스가 스프링 데이터 JPA 레포지토리임을 나타냄
public interface AddressRepository extends JpaRepository<Address, Long> {
    // JpaRepository는 기본적인 CRUD 메소드(findAll, findById, save, delete 등)를 제공
}
