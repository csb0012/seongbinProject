package com.springboot.react.controller;

import com.springboot.react.entity.Member;
import com.springboot.react.service.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Optional;

@RestController
@RequestMapping("/api/members")
public class MemberController {

    private static final Logger logger = LoggerFactory.getLogger(MemberController.class);
    private final MemberService memberService;
    private final BCryptPasswordEncoder passwordEncoder;

    @Autowired
    public MemberController(MemberService memberService, BCryptPasswordEncoder passwordEncoder) {
        this.memberService = memberService;
        this.passwordEncoder = passwordEncoder;
    }

    private final Path rootLocation = Paths.get("C:/react_images");

    @PostMapping("/upload")
    public ResponseEntity<?> uploadImage(@RequestParam("image") MultipartFile file,
                                         @RequestParam("member") String memberStr) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        Member member = objectMapper.readValue(memberStr, Member.class);

        String fileName = file.getOriginalFilename();
        Files.copy(file.getInputStream(), this.rootLocation.resolve(fileName), StandardCopyOption.REPLACE_EXISTING);

        String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath().path("/downloadFile/")
                .path(fileName).toUriString();
        member.setImagePath(fileDownloadUri);

        Member savedMember = memberService.saveMember(member);

        return ResponseEntity.ok("회원 가입 정보가 등록되었습니다. ID: " + savedMember.getMemberNumber());
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Member loginRequest) {
        // 입력된 로그인 정보 확인
        logger.info("로그인 시도: 아이디={}, 비밀번호={}", loginRequest.getMemberId(), loginRequest.getMemberPassword());

        // 데이터베이스에서 회원 정보 찾기
        Optional<Member> foundMember = memberService.findByMemberId(loginRequest.getMemberId());

        if (!foundMember.isPresent()) {
            logger.info("로그인 실패: 아이디 {}가 존재하지 않음", loginRequest.getMemberId());
            return ResponseEntity.badRequest().body("로그인 아이디가 잘못 되었습니다!");
        }

        Member member = foundMember.get();
        logger.info("데이터베이스에서 찾은 비밀번호: {}", member.getMemberPassword());

        // 비밀번호 일치 여부 확인
        if (!passwordEncoder.matches(loginRequest.getMemberPassword(), member.getMemberPassword())) {
            logger.info("로그인 실패: 비밀번호 불일치. 입력된 비밀번호={}, 저장된 비밀번호={}", loginRequest.getMemberPassword(), member.getMemberPassword());
            return ResponseEntity.badRequest().body("패스워드가 잘못 되었습니다!");
        }

        logger.info("로그인 성공: 아이디={}, 로그인 성공: 패스워드={}", loginRequest.getMemberId(), loginRequest.getMemberPassword());
        return ResponseEntity.ok(member);
    }

    @PutMapping("/update/{memberId}")
    public ResponseEntity<?> updateMember(@PathVariable String memberId, 
                                          @RequestParam(value = "image", required = false) MultipartFile file,
                                          @RequestParam("member") String memberStr) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        Member memberToUpdate = objectMapper.readValue(memberStr, Member.class);

        Member existingMember = memberService.findByMemberId(memberId)
                .orElseThrow(() -> new RuntimeException("Member not found with id " + memberId));

        if (file != null && !file.isEmpty()) {
            String fileName = file.getOriginalFilename();
            Files.copy(file.getInputStream(), this.rootLocation.resolve(fileName), StandardCopyOption.REPLACE_EXISTING);
            String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath().path("/downloadFile/")
                    .path(fileName).toUriString();
            existingMember.setImagePath(fileDownloadUri);
        }
        existingMember.setMemberName(memberToUpdate.getMemberName());
        existingMember.setMemberPhone(memberToUpdate.getMemberPhone());
        existingMember.setAddress(memberToUpdate.getAddress());
        existingMember.setAddressDetail(memberToUpdate.getAddressDetail());
        existingMember.setGender(memberToUpdate.getGender());

        // 비밀번호가 null 또는 빈 값이 아닌 경우에만 비밀번호를 업데이트하고 암호화
        if (memberToUpdate.getMemberPassword() != null && !memberToUpdate.getMemberPassword().isEmpty()) {
            logger.info("회원정보 수정 시 비밀번호 암호화 전: {}", memberToUpdate.getMemberPassword());

            // 기존 비밀번호와 다를 때만 암호화
            if (!passwordEncoder.matches(memberToUpdate.getMemberPassword(), existingMember.getMemberPassword())) {
                existingMember.setMemberPassword(passwordEncoder.encode(memberToUpdate.getMemberPassword()));
                logger.info("회원정보 수정 시 비밀번호 암호화 후: {}", existingMember.getMemberPassword());
            } else {
                logger.info("비밀번호가 변경되지 않음. 기존 비밀번호 유지.");
            }
        }

        // 회원 정보 저장
        Member updatedMember = memberService.saveMember(existingMember);
        return ResponseEntity.ok("회원 정보가 수정되었습니다. ID: " + updatedMember.getMemberNumber());
    }
    
    @GetMapping("/{memberId}")
    public ResponseEntity<Member> getMemberByMemberId(@PathVariable String memberId) {
        Optional<Member> member = memberService.findByMemberId(memberId); // ID로 게시글 검색
        if (!member.isPresent()) { // 게시글이 존재하지 않을 경우
            return ResponseEntity.notFound().build(); // 404 Not Found 응답 반환
        }
        return ResponseEntity.ok(member.get()); 
    }

    @DeleteMapping("/{memberId}")
    public ResponseEntity<?> deleteMember(@PathVariable String memberId) {
        try {
            memberService.deleteMember(memberId);
            return ResponseEntity.ok().body("회원 탈퇴가 성공적으로 처리되었습니다.");
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
