package com.springboot.react.service;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.springboot.react.entity.Notice_mjh;

public interface NoticeService_mjh {
	// 게시글 저장 메소드 (이 메서드는 주어진 Notice_mjh 객체를 데이터베이스에 저장하고 저장된 객체를 반환합니다.)
	// 파라미터: Notice_mjh 객체
	// 반환 : 저장된 Notice_mjh 객체
	Notice_mjh saveNotice_mjh(Notice_mjh notice_mjh);
	
	Page<Notice_mjh> findAll(Pageable pageable);
	
	Optional<Notice_mjh> findById(Long id);
	
	Optional<Notice_mjh> findNotice_mjhById(Long id);
	
	Page<Notice_mjh> findAllBySearch(String search, Pageable pageable);
	
	Notice_mjh updateNotice_mjh(Long id, Notice_mjh notice_mjh);
	
	void deleteNotice_mjh(Long id);
}
