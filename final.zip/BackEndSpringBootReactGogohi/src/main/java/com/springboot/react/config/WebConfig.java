package com.springboot.react.config;
// 필요한 스프링 프레임워크 클래스들을 임포트합니다.
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

// 스프링 부트에서 CORS 설정을 적용하기 위해 WebMvcConfigurer 인터페이스를 구현합니다.
@Configuration  // 이 클래스를 스프링 구성(설정) 클래스로 선언합니다.
public class WebConfig implements WebMvcConfigurer {
    // CORS 설정을 추가하는 메소드입니다.
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")  // 모든 경로에 대하여 CORS 정책을 적용합니다.
            .allowedOrigins("*","http://192.168.10.23:3000", "http://localhost:3000")  // 접근을 허용할 출처를 지정합니다.
            // .allowedOrigins("http://현재PC IP 주소 입력:3000", "http://localhost:3000")  // 다른 출처를 추가할 수 있습니다.
            .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")  // 허용할 HTTP 메소드를 지정합니다.
            .allowedHeaders("*")  // 모든 HTTP 헤더를 허용합니다.
            .allowCredentials(false);  // 자격 증명(예: 쿠키)을 포함한 요청을 허용합니다.
    }
    
    // 정적 리소스의 처리를 위한 핸들러를 추가하는 메소드입니다.
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/react_images/**")  // '/react_images/'로 시작하는 모든 요청을 처리합니다.
            .addResourceLocations("file:///C:/react_images/");  // 이 경로에서 리소스를 찾습니다.
        registry.addResourceHandler("/downloadFile/**")
		.addResourceLocations("file:///C:/react_images/");
    }
}
