import React from 'react';
import '../css/paginationSje.css';

const PaginationSje = ({ currentPage, totalPages, paginate }) => {
    const pageNumbers = [];

    // 화면에 표시할 페이지 번호 범위를 계산
    const startPage = Math.max(1, currentPage - 2);
    const endPage = Math.min(totalPages, currentPage + 2);

    for (let i = startPage; i <= endPage; i++) {
        pageNumbers.push(i);
    }

    return (
        <div id='paging_button'>
            {/* 처음 페이지로 이동 버튼 */}
            <button onClick={() => paginate(1)} disabled={currentPage === 1}>
                <img src="images_sje/chevrons_left_icon.svg" alt="<<" />
            </button>
            {/* 이전 페이지로 이동 버튼 */}
            <button onClick={() => paginate(currentPage - 1)} disabled={currentPage === 1}>
                <img src="images_sje/left_icon.svg" alt="<" />
            </button>

            {/* 동적으로 생성된 페이지 번호 */}
            <span>
                {pageNumbers.map(number => (
                    <button 
                        key={number} 
                        onClick={() => paginate(number)} 
                        className={number === currentPage ? 'active' : ''}
                    >
                        {number}
                    </button>
                ))}
            </span>

            {/* 다음 페이지로 이동 버튼 */}
            <button onClick={() => paginate(currentPage + 1)} disabled={currentPage === totalPages}>
                <img src="images_sje/right_icon.svg" alt=">" />
            </button>
            {/* 마지막 페이지로 이동 버튼 */}
            <button onClick={() => paginate(totalPages)} disabled={currentPage === totalPages}>
                <img src="images_sje/chevrons_right_icon.svg" alt=">>" />
            </button>
        </div>
    );
}

export default PaginationSje;
