import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams, useHistory } from 'react-router-dom';
import '../css/postDetail_sje.css';

function PostDetail_sje() {
    const [post_sje, setPost] = useState({});
    const { boardNumber } = useParams();  // 현재 게시글의 boardNumber를 URL 파라미터에서 가져옴
    const history = useHistory();

    // 게시글을 불러오는 useEffect
    useEffect(() => {
        const fetchPost = async () => {
            try {
                const response = await axios.get(`http://localhost:9008/api/posts_sje/${boardNumber}`);
                setPost(response.data);  // 게시글 데이터 설정
            } catch (error) {
                console.log(error);
            }
        };
        fetchPost();
    }, [boardNumber]);

    // 게시글 삭제 함수
    const handleDelete = async () => {
        if (window.confirm("게시글을 삭제하시겠습니까?")) {
            try {
                await axios.delete(`${process.env.REACT_APP_API_BASE_URL}/api/posts_sje/${boardNumber}`);
                alert('게시글이 삭제되었습니다.');
                history.push('/postList_sje');  // 삭제 후 게시글 목록으로 이동
            } catch (error) {
                console.error("게시글 삭제 실패", error);
            }
        }
    };

    // 글목록으로 이동하는 함수
    const goToPostList = () => {
        history.push('/postList_sje');
    };

    return (
        <div id='postDetail_sje'>
            <div style={{width:'100', height:'56px'}} />
            <div className='wrapper'>
                <div className='header'>
                    <div className='header-c'>
                        <p className='number'>{post_sje.boardNumber}</p>
                        <p className='bar'>|</p>
                        <p className='writer'>작성자: {post_sje.boardWriter}</p>
                    </div>
                    <h2 className='title'>{post_sje.boardTitle}</h2>
                    <div className='e-d'>
                        <button onClick={() => history.push(`/edit_sje/${boardNumber}`)}>수정</button>
                        <button onClick={handleDelete}>삭제</button>
                    </div>
                </div>
                <div className='content'>
                <hr />
                </div>
                <div className='contents'>
                    <p>{post_sje.boardContents}</p>
                </div>
                <div className='buttons'>
                    <button onClick={goToPostList}>글목록으로</button>
                </div>
            </div>
        </div>
    );
}

export default PostDetail_sje;
