// React와 관련된 기능들을 import 합니다.
import React, { useState } from 'react';
// React Router DOM에서 useHistory 훅을 import 합니다. 이는 프로그래밍 방식으로 라우팅을 할 수 있게 도와줍니다.
import { useHistory } from 'react-router-dom';
import '../css/infopayment_mjh.css';

// Index 컴포넌트 정의
function InfoPayment_mjh() {
  // formData 상태를 useState 훅을 사용하여 초기화합니다. 초기 상태는 모든 필드가 빈 문자열입니다.
  const [formData, setFormData] = useState({
    name: '학교 사랑 후원',
    amount: '',
    buyer_email: '',
    buyer_name: '',
    buyer_tel: '',
    buyer_addr: '',
    buyer_postcode: ''
  });

  // history 객체를 사용하여 페이지 이동을 제어합니다.
  const history = useHistory();

  // 입력 필드 값이 변경될 때마다 호출되는 handleChange 함수.
  // 이벤트 객체에서 입력 필드의 이름(name)과 값을(value) 추출하여 formData 상태를 업데이트합니다.
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // 폼 제출 이벤트를 처리하는 handleSubmit 함수.
  // 기본 이벤트를 방지하고, formData를 사용하여 URLSearchParams 객체를 생성 후,
  // 이를 문자열로 변환하여 결제 페이지로 라우트합니다(`history.push`를 사용).
  const handleSubmit = (e) => {
    e.preventDefault();
    const query = new URLSearchParams(formData).toString();
    history.push(`/payment_mjh?${query}`);
  };

  // 컴포넌트의 JSX 구조를 반환합니다.
  // 메인 페이지 타이틀과 폼, 그리고 여러 입력 필드들이 정의되어 있습니다.
  // 각 입력 필드는 onChange 이벤트에 handleChange 함수를 연결하여 상태가 업데이트되도록 설정합니다.
  return (
    <div className='infopayPage_mjh'>
      <h1 className='infopayHead_mjh'>학교 사랑 후원</h1>
      <div className='infopayFormWrapper_mjh'>
        <div className='infopayNotice_mjh'>
          후원정보를 입력해 주세요. *는 필수 입력사항 입니다. 
        </div>
        <form onSubmit={handleSubmit}>
          <div className='infoPayEmail_mjh'>
          <div>
            <span>후원자명 *</span>
            <input type="text" name="buyer_name" onChange={handleChange} />
          </div>
            <span>Email *</span>
            <input type="email" name="buyer_email" onChange={handleChange} />
          </div>
         
          <div>
            <span>연락처 *</span>
            <input type="tel" name="buyer_tel" placeholder='-를 제외한 숫자만 입력해주세요.' onChange={handleChange} />
          </div>
          <div>
            <span>주소</span>
            <input type="text" name="buyer_addr" onChange={handleChange} />
          </div>
          <div>
            <span>우편번호</span>
            <input type="text" name="buyer_postcode" onChange={handleChange} />
          </div>
          <div>
            <span>후원금액 *</span>
            <input type="number" name="amount" onChange={handleChange} />
          </div>
          <br />
          <button className='infopayButton_mjh' type="submit">후원하기</button>
        </form>
      </div>
    </div>
  );
}

// Index 컴포넌트를 기본 내보내기로 설정합니다.
export default InfoPayment_mjh;
