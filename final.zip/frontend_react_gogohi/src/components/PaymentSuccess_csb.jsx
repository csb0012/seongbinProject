import React from 'react';
import { Link } from 'react-router-dom';

function PaymentSuccess_csb() {
  return (
    <div>
      <h1>결제완료</h1>
      <p>결제 처리가 제대로 되었습니다.</p>
      <Link to="/">[처음으로]</Link>
    </div>
  );
}

export default PaymentSuccess_csb;