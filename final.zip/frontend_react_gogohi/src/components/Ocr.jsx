// React 및 필요한 라이브러리들 임포트
import React, { useState } from 'react';
import axios from 'axios';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import '../css_csb/OCR_csb.css';

const App = () => {
  const [pdfFile, setPdfFile] = useState(null);
  const [loading, setLoading] = useState(false); // 로딩 상태 관리

  const handleFileChange = (e) => {
    setPdfFile(e.target.files[0]);
  };

  const handleUpload = async () => {
    if (!pdfFile) {
      alert('PDF 파일을 선택하세요!');
      return;
    }

    const formData = new FormData();
    formData.append('pdf', pdfFile);
    
    setLoading(true); // 데이터 처리 시작 시 로딩 상태 true로 설정

    try {
      const response = await axios.post("http://localhost:5001/upload", formData);
      console.log(response.data);
      alert("빅데이터 크롤링이 완료되었습니다!");
      setPdfFile(null);
      document.getElementById('pdfInput').value = "";
    } catch (error) {
      console.error("Error:", error.response ? error.response.data : error.message);
      alert("오류가 발생했습니다!");
    } finally {
      setLoading(false); // 처리 완료 후 로딩 상태 false로 설정
    }
  };

  return (
    <Router>
      <Switch>
        <Route path="/">
          <div className="container4">
            <h1>빅데이터 학교 정보 크롤링</h1>
            <input 
              id="pdfInput"
              type="file"
              accept="application/pdf"
              onChange={handleFileChange}
            />
            <button className="csb" onClick={handleUpload}>공공 빅데이터 학교 정보 크롤링 시작</button>
            {loading && <p>데이터 크롤링중...</p>} {/* 로딩 상태에 따라 메시지 표시 */}
          </div>
        </Route>
      </Switch>
    </Router>
  );
};

export default App;
