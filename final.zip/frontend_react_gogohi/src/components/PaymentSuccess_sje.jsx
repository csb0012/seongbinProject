import React from 'react';
import { Link } from 'react-router-dom';
import '../css/paymentSuccess_sje.css';

function PaymentSuccess_sje() {
    return (
        <div id='paymentSuccess_sje'>
            <div style={{width:'100', height:'56px'}} />
            <div className='wrapper'>
                <h1 className='header'>결제완료</h1>
                <hr />
                <div className='content'>
                    <img src="images_sje/logo_hi.svg" alt="" />
                    <div className='content2'>
                        <h4>후원해 주셔서 감사합니다.</h4>
                        <br />
                        <p>후원해 주신 소중한 금액은 장학기금 및 학교 발전 기금으로 사용되어, 도움이 필요한 학생들의 교육 지원과 학교의 다양한 발전 프로그램에 큰 기여를 하게 됩니다. 여러분의 후원은 미래 인재 양성과 교육 환경 개선에 큰 힘이 됩니다.</p>
                        <br />
                        <p>다시 한 번 깊이 감사드리며, 앞으로도 많은 관심과 응원 부탁드립니다.</p>
                        <br />
                        <Link className='pay-link' to="/main">메인으로</Link>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default PaymentSuccess_sje;