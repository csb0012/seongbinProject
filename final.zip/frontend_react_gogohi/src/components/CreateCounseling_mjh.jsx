import React, { useState } from 'react';
import axios from 'axios';
import '../css/createCounseling_mjh.css';
import { useHistory } from 'react-router-dom/cjs/react-router-dom.min';

function CreateCounseling_mjh() {
    const [counsel, setCounsel] = useState({
        counselingTitle: '',
        counselingContents: '',
        counselingWriter: '',
        counselingEmail:'',
        counselingDate: '',
        avgRank:''
    });

    const history = useHistory();
        const goToList = () =>{
            history.push('/listCounsel');
        }

    const handleChange = (e) =>  {
        const { name, value } = e.target;
        setCounsel({
            ...counsel,
            [name]: value
        });

    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post('http://localhost:9008/api/counseling_mjh', counsel);
            alert('게시글이 등록 되었습니다.');
            console.log("데이터 전송 :" , response.data);
            history.push("listCounsel");
        } catch (error) {
            console.log("게시글 등록 실패", error);
            alert('게시글 등록에 실패했습니다!');
        }
    }

    return (
        <div className='counselWrapper'>
            <h2 className='counselHead'>진학 희망 학생 상담 등록</h2>
            <div className='important_mjh'>
                <h3>유의 사항</h3> 
                <div className='li_mjh'>
                    <li> 수집한 개인정보는 답변 및 회신을 위해서만 사용되며, 문의자의 문의 목적 달성 즉시 해당 개인정보는 파기됩니다. 
                    </li>
                    <li>※ 학년별 학기 성적, 본인의 관심과목, 지역, 학교 내 기숙사여부 등 상세히 적어주시면 추후 상담시 도움이 됩니다. </li>
                    <li>해당 게시판 목적에 부합되지 않는 게시글은 통보없이 삭제 또는 관리자 전용 게시판으로 이동됩니다.
                        <br />(광고성 게시물, 명예훼손 게시물, 허위사실, 불법성게시물, 불쾌감, 혐오감을 조성하는 게시물, 기타 분란조장 게시물 등 )</li></div> 
            </div>
            <div className='inputWrapper_mjh'>
                <form onSubmit={handleSubmit}>
                    <div className='counselLabelWrapper_mjh'>
                        <div className='counselWriter_mjh'>작성자</div>
                        <div className='counselEmail_mjh'>E-mail</div>
                        <div className='counselTitle_mjh'>제목</div>
                        <div className='counselcontent_mjh'>내용</div>
                    </div> {/*  counselLabelWrapper_mjh */}
                    <div className='input1_mjh'>
                        <input className='writer_mjh' type="text" name='counselingWriter' placeholder='작성자' onChange={handleChange}/>
                        <label className='date_mjh'>등록일자</label>
                        <input type="date" className='counselingDate' name='counselingDate' placeholder='' onChange={handleChange}/>
                    </div>
                    <div className='EmailWrapper_mjh'>
                        <input className='Email_mjh' type="text" name="counselingEmail" placeholder='Email 주소를 입력하세요.'onChange={handleChange} size={40} />
                        <label className='rank_label_MJH'>평균내신등급<input className='rank_mjh' type="text" name="avgRank" placeholder='* 'onChange={handleChange} size={10} /></label>
                    </div>

                    <div className='titleWrapper_mjh'>
                        <input className='title_mjh' type='text' name='counselingTitle' placeholder='제목' onChange={handleChange} size={60}/>
                    </div>
                    <div className='contentWrapper_mjh'>
                        <textarea className='content_mjh' name="counselingContents" placeholder='내용
                         ' onChange={handleChange} />
                    </div>
                   
                    <div className='btn_mjh'>
                        <button type='submit'>등록</button>
                        <button onClick={goToList} type='reset'>취소</button>
                    </div>
                </form>
              
            </div>
        </div>
    );
}

export default CreateCounseling_mjh;