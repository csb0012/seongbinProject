import React from 'react';
import "../css/main_sje.css";
import { Link } from 'react-router-dom';

function Main_sje() {
    return (
        <div id='main-sje'>
            <div style={{width:'100', height:'56px'}} />
            <div className='wrapper'>
                <div className='main-banner'>
                    <img className='m-full' src="images_sje/main_full.jpg" alt="메인배너1" />
                    <img className='m-t' src="images_sje/main_t.jpg" alt="메인배너2" />
                    <img className='m-m' src="images_sje/main_m.jpg" alt="메인배너3" />
                </div>
                <div className='content'>
                    <div className='content-1'>
                        <div className='con1-1'>
                        <img className='icon' src="images_sje/m_icon1_sje.svg" alt="공지사항" />
                            <p className='header'>공지사항</p>
                            <ul>
                                <Link to="/02"><li>2025년 입학설명회</li></Link>
                                <Link to="/03"><li>2024년 학사일정</li></Link>
                                <Link to="/04"><li>10월 1일 '국군의 날'의 임시공휴일 변경에 따른 기말고사 연기 안내</li></Link>
                                <Link to="/05"><li>하이중학교 사무직원 대체 근로자 채용공고</li></Link>
                                <div className='hidden'>
                                    <Link to="/01"><li>겨울방학 중 학교 내부 공사</li></Link>
                                    <Link to="/02"><li>제 28회 경기도 국안 경영대회 홍보</li></Link>
                                    <Link to="/03"><li>학교 외부인 출입 통제 안내문</li></Link>
                                </div>
                            </ul>
                        </div>
                        <div className='con1-2'>
                            <img className='icon' src="images_sje/m_icon2_sje.svg" alt="가정통신문" />
                            <p className='header'>가정통신문</p>
                            <ul>
                                <Link to="/02"><li>2024학년도 2학기 중간고사 일정 안내</li></Link>
                                <Link to="/03"><li>교내 체육대회 우천 시 연기 안내</li></Link>
                                <Link to="/04"><li>학생 안전교육 실시 안내</li></Link>
                                <Link to="/05"><li>교내 동아리 모집 및 신청 방법 안내</li></Link>
                                <div className='hidden'>
                                    <Link to="/01"><li>방과 후 학교 프로그램 신청 안내</li></Link>
                                    <Link to="/02"><li>교내 소방 훈련 및 대피 안내</li></Link>
                                    <Link to="/03"><li>겨울방학 방과 후 수업 신청 안내</li></Link>
                                </div>
                            </ul>
                        </div>
                    </div>
                    <div className='content-2'>
                        <div className='content-2-link'>
                            <Link to="/test">자세히보기 ▶</Link>
                        </div>
                        <img className='s-full' src="images_sje/subbanner_sje.jpg" alt="서브배너" />
                        <img className='s-t' src="images_sje/subbanner2_sje.jpg" alt="서브배너" />
                        <img className='s-m' src="images_sje/subbanner3_sje.jpg" alt="서브배너" />
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Main_sje;