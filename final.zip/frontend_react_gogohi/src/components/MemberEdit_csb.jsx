import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useHistory } from 'react-router-dom';
import '../css_csb/MemberEdit_csb.css'; // CSS 파일 import

function MemberEdit_csb7() {
    const history = useHistory();
    const memberData = JSON.parse(localStorage.getItem("loggedInMember"));
    const [memberId, setMemberId_csb7] = useState(memberData ? memberData.memberId : '');
    const [member, setMember_csb7] = useState(null);
    const [file, setFile_csb7] = useState(null); // 이미지 파일 상태 추가
    const [preview, setPreview_csb7] = useState(null); // 이미지 미리보기 추가
    const [updatedMember, setUpdatedMember_csb7] = useState({
        memberId: memberData ? memberData.memberId : '',
        memberPassword: '', // 기존 비밀번호를 입력하거나 새 비밀번호로 덮어씌울 수 있도록 함
        memberName: '',
        memberPhone: '',
        address: '',
        addressDetail: '',
        gender: 'male' // 기본값으로 '남자' 설정
    });

    // 회원 정보 불러오기
    useEffect(() => {
        if (memberId) {
            axios.get(`http://localhost:9008/api/members/${memberId}`)
                .then(response => {
                    setMember_csb7(response.data);
                    setUpdatedMember_csb7({
                        memberId: response.data.memberId,
                        memberName: response.data.memberName || '',
                        memberPhone: response.data.memberPhone || '',
                        address: response.data.address || '',
                        addressDetail: response.data.addressDetail || '',
                        gender: response.data.gender || 'male' // 기본값 'male'
                    });
                    setPreview_csb7(response.data.imagePath); // 기존 이미지로 미리보기 설정
                })
                .catch(error => console.error('회원 데이터 가져오기 오류:', error));
        }
    }, [memberId]);

    // 입력 필드 변경 처리
    const handleChange_csb7 = (e) => {
        const { name, value } = e.target;
        console.log('입력 필드 변경:', name, value);  // 입력된 값을 로그로 확인
        setUpdatedMember_csb7({
            ...updatedMember,
            [name]: value
        });
    };

    // 성별 변경 처리 (라디오 버튼 선택 시)
    const handleGenderChange_csb7 = (e) => {
        setUpdatedMember_csb7({
            ...updatedMember,
            gender: e.target.value
        });
    };

    // 이미지 파일 선택 및 미리보기 처리
    const handleFileChange_csb7 = (e) => {
        const file = e.target.files[0];
        setFile_csb7(file);
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setPreview_csb7(reader.result); // 이미지 미리보기 설정
            };
            reader.readAsDataURL(file);
        }
    };

    // 회원 정보 업데이트
    const handleUpdate_csb7 = async () => {
        // 상태 업데이트가 완료된 후 데이터를 확인하기 위해 업데이트된 상태를 사용
        let updatedData = { ...updatedMember };
    
        // 비밀번호가 비어 있으면 필드에서 제거
        if (!updatedData.memberPassword || updatedData.memberPassword.trim() === '') {
            console.log('비밀번호가 비어 있음, 제거됩니다.');
            delete updatedData.memberPassword;
        }
    
        // 전송할 데이터를 콘솔에 출력
        console.log('전송할 데이터 (필드 제거 후):', updatedData);
    
        const formData = new FormData();
        formData.append('member', JSON.stringify(updatedData));
    
        if (file) {
            formData.append('image', file);
        }
    
        // 콘솔 로그 확인
        formData.forEach((value, key) => {
            console.log(`${key}: ${value}`);
        });
    
        try {
            await axios.put(`http://localhost:9008/api/members/update/${memberId}`, formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                }
            });
            alert('회원 정보가 업데이트되었습니다.');
            history.push('/');
        } catch (error) {
            console.error('회원 정보 업데이트 오류:', error);
            alert('회원 정보 업데이트에 실패했습니다.');
        }
    };

    return (
        <div className="login-main_csb7">
            <h1 className="login-header_csb7">회원정보 수정</h1>
            {member ? (
                <div className="member-details_csb7">
                    <div className="image-container_csb7">
                        <img 
                            src={preview || "http://localhost:9008/react_images/user.png"} 
                            alt='프로필 이미지' 
                            className="profile-image_csb7" 
                        />
                        <input type="file" onChange={handleFileChange_csb7} className="file-input_csb7"/>
                    </div>
                    <div className="form-container_csb7">
                        <div>
                            <label>아이디: {updatedMember.memberId}</label>
                        </div>
                        <div>
                        <label>비밀번호:</label>
                        <input
                            type="password"
                            name="memberPassword"
                            value={updatedMember.memberPassword}
                            onChange={handleChange_csb7}
                            placeholder="비밀번호를 변경할 수 있습니다."
                            className="input-field_csb7" // 추가된 클래스
                        />
                    </div>
                        <div>
                            <label>이름:</label>
                            <input
                                type="text"
                                name="memberName"
                                value={updatedMember.memberName}
                                onChange={handleChange_csb7}
                            />
                        </div>
                        <div>
                            <label>전화번호:</label>
                            <input
                                type="text"
                                name="memberPhone"
                                value={updatedMember.memberPhone}
                                onChange={handleChange_csb7}
                            />
                        </div>
                        <div>
                            <label>주소:</label>
                            <input
                                type="text"
                                name="address"
                                value={updatedMember.address}
                                onChange={handleChange_csb7}
                            />
                        </div>
                        <div>
                            <label>상세 주소:</label>
                            <input
                                type="text"
                                name="addressDetail"
                                value={updatedMember.addressDetail}
                                onChange={handleChange_csb7}
                            />
                        </div>
                        <div>
                            <label>성별:</label>
                            <div>
                                <label>
                                    <input 
                                        type="radio" 
                                        value="male" 
                                        checked={updatedMember.gender === 'male'} 
                                        onChange={handleGenderChange_csb7}
                                    /> 남자
                                </label>
                                <label>
                                    <input 
                                        type="radio" 
                                        value="female" 
                                        checked={updatedMember.gender === 'female'} 
                                        onChange={handleGenderChange_csb7}
                                    /> 여자
                                </label>
                            </div>
                        </div>
                        <div className="button-container_csb7">
                            <button onClick={handleUpdate_csb7} className="update-button_csb7">회원 정보 수정</button>
                            <button onClick={() => history.push('/')} className="main-button_csb7">메인으로 이동</button>
                        </div>
                    </div>
                </div>
            ) : (
                <p>로그인되지 않았습니다.</p>
            )}
        </div>
    );
}

export default MemberEdit_csb7;
