import React, { useState } from 'react';
import axios from 'axios';
import '../css/AddressPopup.css';  // CSS 파일 import

function AddressPopup({ onClose, onSelect }) {
    const [searchText, setSearchText] = useState('');
    const [addressContents, setAddressContents] = useState([]);
    const [totalCount, setTotalCount] = useState(0);
    const [page, setPage] = useState(1);
    const [emptyListViewVisible, setEmptyListViewVisible] = useState(false);

    const handleSearch = () => {
        if (searchText === '') {
            alert('주소를 입력해주세요');
        } else {
            setPage(1);
            fetchAddress(1);
        }
    };

    const fetchAddress = async (page) => {
        try {
            const response = await axios.get(
                'https://business.juso.go.kr/addrlink/addrLinkApi.do', {
                    params: {
                        confmKey: 'devU01TX0FVVEgyMDI0MDkwNjE0MTgxMDExNTA2OTg=',
                        currentPage: page,
                        countPerPage: 4,
                        keyword: searchText,
                        resultType: 'json'
                    }
                }
            );

            const data = response.data;
            if (data.results.juso.length === 0) {
                setEmptyListViewVisible(true);
            } else {
                setEmptyListViewVisible(false);
                setAddressContents(data.results.juso);
                setTotalCount(data.results.common.totalCount);
            }
        } catch (error) {
            console.error('주소를 가져오는 중 오류가 발생했습니다:', error);
            alert('주소를 가져오는 중 오류가 발생했습니다.');
        }
    };

    const handleAddressClick = (address) => {
        onSelect(address);
    };

    const pageDownClicked = () => {
        if (page > 1) {
            setPage(page - 1);
            fetchAddress(page - 1);
        }
    };

    const pageUpClicked = () => {
        if (page < Math.ceil(totalCount / 4)) {
            setPage(page + 1);
            fetchAddress(page + 1);
        }
    };

    const handleKeyPress = (e) => {
        if (e.key === 'Enter') {
            handleSearch();
        }
    };

    return (
        <div className="popup-overlay">
            <div className="popup-container">
                <div className="search-container">
                    <input
                        type="text"
                        value={searchText}
                        onChange={(e) => setSearchText(e.target.value)}
                        onKeyPress={handleKeyPress}  // Enter 키 이벤트
                        placeholder="도로명 또는 지번을 입력하세요"
                        className="search-input"
                    />
                    <button onClick={handleSearch} className="search-button">
                        검색
                    </button>
                </div>

                {emptyListViewVisible ? (
                    <div className="no-result">검색 결과가 없습니다.</div>
                ) : (
                    <ul className="address-list">
                        {addressContents.map((item, index) => (
                            <li key={index} onClick={() => handleAddressClick(item.roadAddr)} className="address-item">
                                <span className="zip-code">우편번호: {item.zipNo}</span>
                                <span className="road-address">도로명: {item.roadAddr}</span>
                                <span className="jibun-address">지번: {item.jibunAddr}</span>
                            </li>
                        ))}
                    </ul>
                )}

                <div className="pagination-container">
                    <button onClick={pageDownClicked} className="pagination-button">
                    <img src="/images/btn_prev.png" alt="이전 페이지" />
                    </button>
                    <span className="pagination-info">Page {page} / {Math.ceil(totalCount / 4)}</span>
                    <button onClick={pageUpClicked} className="pagination-button">
                    <img src="/images/btn_next.png" alt="다음 페이지" />
                    </button>
                </div>

                <button onClick={onClose} className="close-button">닫기</button>
            </div>
        </div>
    );
}

export default AddressPopup;
