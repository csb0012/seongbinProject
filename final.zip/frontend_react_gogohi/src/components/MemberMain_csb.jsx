import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';
import axios from 'axios';
import '../css_csb/MemberMain_csb.css'; // CSS 파일 import

function MemberMain_csb() {
    const history = useHistory();
    const [loginInfo, setLoginInfo] = useState({
        memberId: '',
        memberPassword: '',
        gender: 'male' // 기본값 설정
    });

    const handleChange = (e) => {
        setLoginInfo({ ...loginInfo, [e.target.name]: e.target.value });
    };

    const handleLogin = async () => {
        try {
            const response = await axios.post('http://localhost:9008/api/members/login', loginInfo, {
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            const memberData = response.data;
            localStorage.setItem("loggedInMember", JSON.stringify(memberData));

            alert('로그인에 성공했습니다.');
            window.location.href = '/main';
        } catch (error) {
            console.error('로그인 에러', error);
            alert('로그인에 실패했습니다.');
        }
    };

    const gomain = () => {
        history.push('/');
    };

    const handleCancel = () => {
        setLoginInfo({ memberId: '', memberPassword: '', gender: 'male' });
    };

    return (
        <div className="member-main_csb">
            <div className="login-form_csb2">
                <h2 className="login-header_csb">로그인</h2>
                <input
                    type='text'
                    name='memberId'
                    value={loginInfo.memberId}
                    onChange={handleChange}
                    placeholder='아이디'
                    className="input-password_csb" // className 변경
                />
                <br />
                <input
                    type='password'
                    name='memberPassword'
                    value={loginInfo.memberPassword}
                    onChange={handleChange}
                    placeholder='비밀번호'
                    className="input-password_csb" // className 동일하게 설정
                />
                <br />
                <button onClick={handleLogin} className="login-button_csb">로그인</button>
                <button onClick={handleCancel} className="cancel-button_csb">취소</button>
                <button onClick={gomain} className="cancel-button_csb">메인으로 이동</button>
                <h5 style={{fontSize:'16px'}}>아이디가 없으십니까?</h5>
                <button onClick={() => history.push('/register')} className="button_csb">회원 가입하러가기</button>
            </div>
        </div>
    );
}

export default MemberMain_csb;
