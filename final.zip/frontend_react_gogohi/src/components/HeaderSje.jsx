import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import "../css/header_sje.css";

function HeaderSje() {
    const memberData_csb1 = JSON.parse(localStorage.getItem("loggedInMember")); 

    const handleLogout_csb1 = () => {
        localStorage.removeItem("loggedInMember");
        alert("로그아웃 되었습니다");
        window.location.href = '/'; // 새로고침하면서 '/' 경로로 이동
    };

    const [expanded, setExpanded] = useState(false);

    const handleToggle = () => {
        setExpanded(!expanded);
    };

    const handleClose = () => {
        setExpanded(false);
    };

    return (
        <div id='header-sje'>
            <Navbar expand="lg" className="navbar" expanded={expanded}>
                <div className='content'>
                    <Navbar.Brand className='logo' as={Link} to="/main" onClick={handleClose}>
                        <img src="/images_sje/school_sje.svg" alt="logo" />
                        <p>하이중학교</p>
                    </Navbar.Brand>
                    <Navbar.Toggle aria-controls="responsive-navbar-nav" onClick={handleToggle} />
                    <div className='contents'>
                        <Navbar.Collapse id="responsive-navbar-nav">
                        <div className='menu'>
                            <Nav className="me-auto">
                                <Nav.Link as={Link} to="/about_mdy" onClick={handleClose}>학교소개</Nav.Link>
                                <NavDropdown title="정보마당" id="collapsible-nav-dropdown" className='nav-dropdown'>
                                    {/* <NavDropdown.Item as={Link} to="/test" onClick={handleClose}>학교 알림이</NavDropdown.Item> */}
                                    <NavDropdown.Item as={Link} to="/createCounsel" onClick={handleClose}>진학 희망 학생 상담 등록</NavDropdown.Item>
                                    <NavDropdown.Item as={Link} to="/schoolSearch_sje" onClick={handleClose}>진학 학교 추천</NavDropdown.Item>
                                </NavDropdown>
                                <NavDropdown title="소통마당" id="collapsible-nav-dropdown" className='nav-dropdown'>
                                    <NavDropdown.Item as={Link} to="/listNotice_mjh" onClick={handleClose}>공지사항</NavDropdown.Item>
                                    <NavDropdown.Item as={Link} to="/student_list" onClick={handleClose}>학생 자유게시판</NavDropdown.Item>
                                    <NavDropdown.Item as={Link} to="/listCounsel " onClick={handleClose}>진학 상담 게시판</NavDropdown.Item>
                                    <NavDropdown.Item as={Link} to="/postList_sje" onClick={handleClose}>교직원 자유게시판</NavDropdown.Item>
                                    <NavDropdown.Item as={Link} to="/contact_us" onClick={handleClose}>문의하기</NavDropdown.Item>
                                </NavDropdown>
                                <NavDropdown title="후원마당" id="collapsible-nav-dropdown" className='nav-dropdown'>
                                    <NavDropdown.Item as={Link} to="/donationcombine" onClick={handleClose}>후원 통합페이지</NavDropdown.Item>
                                    <NavDropdown.Divider />
                                    <NavDropdown.Item as={Link} to="/infoPayment_mjh" onClick={handleClose}>학교 사랑 후원결제</NavDropdown.Item>
                                    <NavDropdown.Item as={Link} to="/index_sje" onClick={handleClose}>졸업생 동문 후원결제</NavDropdown.Item>
                                    <NavDropdown.Item as={Link} to="/index_csb" onClick={handleClose}>기업 후원결제</NavDropdown.Item>
                                </NavDropdown>
                                <Nav.Link as={Link} to="/FAQ_MDY" onClick={handleClose}>자주묻는질문</Nav.Link>
                                <Nav.Link as={Link} to="/location" onClick={handleClose}>찾아오시는길</Nav.Link>
                                <NavDropdown title="크롤링" id="collapsible-nav-dropdown" className='nav-dropdown'>
                                    <NavDropdown.Item as={Link} to="/bigdata" onClick={handleClose}>빅데이터 자료수집 Openapi 크롤링</NavDropdown.Item>
                                    <NavDropdown.Item as={Link} to="/ocr" onClick={handleClose}>빅데이터 자료 수집 PDF OCR 크롤링</NavDropdown.Item>
                                    </NavDropdown>
                            </Nav>
                        </div>
                                <div className='login'>
                                {memberData_csb1 ? (
                                    <>
                                        {/* 로그인된 경우에만 표시되는 부분 */}
                                        <Nav.Link as={Link} to="/loginmain" className="member-id_csb1" onClick={handleClose}>
                                            {memberData_csb1.memberName}님
                                        </Nav.Link>
                                        {/* 로그아웃 버튼 */}
                                        <button onClick={handleLogout_csb1} className="logout-button_csb3">로그아웃</button>
                                    </>
                                ) : (
                                    // 로그인되지 않은 경우
                                    <Nav.Link as={Link} to="/membermain" onClick={handleClose}>로그인 | 회원가입</Nav.Link>
                                )}
                            </div>
                        </Navbar.Collapse>
                    </div>
                </div>
            </Navbar>
        </div>
    );
}

export default HeaderSje;
