import React, { useState } from 'react';
import axios from 'axios';
import AddressPopup from './AddressPopup.jsx';
import { useHistory } from 'react-router-dom';
import '../css_csb/MemberRegister_csb.css'; // CSS 파일 import

function MemberRegister_csb() {
    const history = useHistory();
    const [member, setMember] = useState({
        memberId: '',
        memberPassword: '',
        memberName: '',
        memberPhone: '',
        address: '',
        addressDetail: '',
        gender: 'male', // 기본값 설정
        imagePath: 'C:/react_images/user.png',
    });

    const [selectedFile, setSelectedFile] = useState(null);
    const [previewUrl, setPreviewUrl] = useState(null);
    const [isPopupOpen, setIsPopupOpen] = useState(false);
    const [selectedAddress, setSelectedAddress] = useState('');
    const [subAddress, setSubAddress] = useState('');

    const handleInputChange = (e) => {
        setMember({ ...member, [e.target.name]: e.target.value });
    };

    const handleFileChange = (e) => {
        setSelectedFile(e.target.files[0]);
        const reader = new FileReader();
        reader.onload = () => {
            setPreviewUrl(reader.result);
        };
        reader.readAsDataURL(e.target.files[0]);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const formData = new FormData();
        formData.append('image', selectedFile);
        formData.append('member', JSON.stringify({
            ...member,
            address: selectedAddress,
            addressDetail: subAddress
        }));

        try {
            const response = await axios.post('http://localhost:9008/api/members/upload', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });
            console.log(response);
            alert('회원가입이 완료되었습니다');
            history.push('/');
        } catch (error) {
            console.error('회원 가입 실패:', error);
            alert('회원 가입에 실패했습니다');
        }
    };

    const handleOpenPopup = () => {
        setIsPopupOpen(true);
    };

    const handleClosePopup = () => {
        setIsPopupOpen(false);
    };

    const handleAddressSelect = (address) => {
        setSelectedAddress(address);
        setIsPopupOpen(false);
    };

    const handleCancel = () => {
        setSelectedAddress('');
        setSubAddress('');
    };

    return (
        <div className="register_csb2">
            <h2 className="register-header_csb2">회원가입</h2>
            <img src={previewUrl || "http://localhost:9008/react_images/human.png"} alt='프로필 이미지' className="image-preview_csb2" />
            <form onSubmit={handleSubmit} className="register-form_csb2">
                <input type='file' onChange={handleFileChange} className="file-input_csb2" />
                <input type='text' name='memberId' placeholder='아이디' onChange={handleInputChange} className="input_csb2" />
                <input type='password' name='memberPassword' placeholder='비밀번호' onChange={handleInputChange} className="input_csb2" />
                <input type='text' name='memberName' placeholder='이름' onChange={handleInputChange} className="input_csb2" />
                <input type='text' name='memberPhone' placeholder='전화번호' onChange={handleInputChange} className="input_csb2" />
                <textarea
                    value={selectedAddress}
                    readOnly
                    placeholder="주소를 선택하세요"
                    rows={selectedAddress ? Math.min(selectedAddress.split('\n').length, 3) : 1}
                    className="input_csb2 address-textarea"
                />
                <button type='button' onClick={handleOpenPopup} className="address-button_csb2">주소 검색</button>
                <input
                    type='text'
                    name='addressDetail'
                    value={subAddress}
                    onChange={(e) => setSubAddress(e.target.value)}
                    placeholder='주소상세'
                    className="input_csb2"
                />
                <div className="gender-select_csb2">
                    <label htmlFor="gender" className="gender-label_csb2">성별:</label>
                    <select
                        name='gender'
                        value={member.gender}
                        onChange={handleInputChange}
                        className="select_csb2"
                    >
                        <option value='male'>남성</option>
                        <option value='female'>여성</option>
                    </select>
                </div>
                <button type='submit' className="submit-button_csb2">회원가입</button>
                <button type='reset' className="cancel-button_csb2" onClick={handleCancel}>취소</button>
            </form>
            <button onClick={() => history.push('/')} className="main-button_csb2">메인으로 이동</button>

            {isPopupOpen && (
                <div className="popup-overlay">
                    <div className="popup-container">
                        <AddressPopup onClose={handleClosePopup} onSelect={handleAddressSelect} />
                    </div>
                </div>
            )}
        </div>
    );
}

export default MemberRegister_csb;
