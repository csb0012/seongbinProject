import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import PaginationSje from './PaginationSje';
import '../css/postList_sje.css';

function PostListSje() {
    const [posts_sje, setPosts] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const postsPerPage = 10;
    const [totalPages, setTotalPages] = useState(0);
    const [isLoaded, setIsLoaded] = useState(false);

    // 검색 관련 상태 변수
    const [searchTerm, setSearchTerm] = useState('');
    const [searchQuery, setSearchQuery] = useState('');

    const fetchPosts = useCallback(async () => {
        setIsLoaded(false);
        try {
            const response = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/posts_sje`, {
                params: {
                    page: currentPage - 1,
                    size: postsPerPage,
                    search: searchQuery,
                },
            });
            setPosts(response.data.content);
            setTotalPages(response.data.totalPages);
            setIsLoaded(true);
        } catch (error) {
            console.error("게시글 목록 조회 에러", error);
            setIsLoaded(true);
        }
    }, [currentPage, postsPerPage, searchQuery]);

    useEffect(() => {
        fetchPosts();
    }, [fetchPosts]);

    const handleSearch = () => {
        setSearchQuery(searchTerm);
        setCurrentPage(1);
    };

    const paginate = (pageNumber) => setCurrentPage(pageNumber);

    return (
        <div id='postList_sje'>
            <div style={{width:'100', height:'56px'}} />
            <div className='wrapper'>
                <h2 className='header'>교직원 자유게시판</h2>
                <hr />
                <div className='content'>
                    <div className='menu'>
                        <ul>
                            <Link to="/listNotice_mjh"><li>공지사항</li></Link>
                            <hr />
                            <Link to="/student_list"><li>학생 자유게시판</li></Link>
                            <hr />
                            <Link to="/listCounsel"><li>진학 상담 게시판</li></Link>
                            <hr />
                            <Link to="/postList_sje"><li>교직원 자유게시판</li></Link>
                            <hr />
                            <Link to="/contact_us"><li>문의하기</li></Link>
                        </ul>
                    </div>
                    <div className='flex'>
                        <div className='search'>
                            <input
                                type="text"
                                placeholder="검색어 입력 (제목, 내용, 작성자)"
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                            />
                            <button className='search-b' onClick={handleSearch}>
                                <img src="images_sje/search_icon_s.svg" alt="검색" />
                            </button>
                        </div>
                        <div className='list'>
                            <ul className='post-h'>
                                <li>
                                    <p className='number'>번호</p>
                                    <p className='title'>제목</p>
                                    <p className='writer'>작성자</p>
                                </li>
                            </ul>
                            {isLoaded && (
                                <>
                                    {posts_sje.length === 0 ? (
                                        <div className='no-posts'>
                                            <p>게시글이 없습니다.</p>
                                        </div>
                                    ) : (
                                        <>
                                            <ul className='post'>
                                                {posts_sje.map(post => (
                                                    <li key={post.boardNumber}>
                                                        <Link to={`/posts_sje/${post.boardNumber}`}>
                                                            <p className='number'>{post.boardNumber}</p>
                                                            <p className='title'>{post.boardTitle}</p>
                                                            <p className='writer'>{post.boardWriter}</p>
                                                        </Link>
                                                        <hr />
                                                    </li>
                                                ))}
                                            </ul>
                                        </>
                                    )}
                                </>
                            )}
                            <div className='pagination'>
                                <div className='page'>
                                    <PaginationSje currentPage={currentPage} totalPages={totalPages} paginate={paginate} />
                                </div>
                                <div className='create'>
                                    <Link to="/postsSje">글쓰기</Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default PostListSje;
