import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';
import axios from 'axios';
import { Link } from 'react-router-dom';
import '../css/createPost_sje.css';

function CreatePost_sje() {

    const history = useHistory();

    const[post_sje, setPost] = useState({
        boardTitle:'',
        boardContents:'',
        boardWriter:''  
    });


    const handleChange = (e) => {
        const {name, value} = e.target;
        setPost({
            ...post_sje,
            [name]: value,
        });
    };


    const handleSubmit = async (e) => {
        e.preventDefault();
    
        try {
            const response = await axios.post('http://localhost:9008/api/posts_sje/upload', 
                null, // 데이터는 쿼리 매개변수로 전달되므로 요청 본문이 필요 없음
                {
                    params: { post: JSON.stringify(post_sje) },
                    headers: {
                        'Content-Type': 'application/json'
                    }
                }
            );
            alert('게시글 등록 성공');
            console.log(response.data);
            history.push("/postList_sje");
        } catch (error) {
            console.error('게시글 등록 실패', error);
            alert('게시글 등록 실패');
        }
    };


    return (
        <div id='createPost_sje'>
            <div style={{width:'100', height:'56px'}} />
            <div className='wrapper'>
                    <form className='header' onSubmit={handleSubmit}>
                        <input type="text" name='boardTitle' placeholder='제목' value={post_sje.boardTitle} onChange={handleChange} />
                    </form>
                    <hr />
                <div className='content'>
                    <div>
                    <div className='contents'>
                        <form onSubmit={handleSubmit}>
                            <br />
                            <textarea name="boardContents" placeholder='내용' value={post_sje.boardContents} onChange={handleChange} />            
                            <br />
                            <input type="text" name="boardWriter" placeholder='작성자' value={post_sje.boardWriter} onChange={handleChange} />
                            <br />
                        </form>
                    </div>
                    <div className='buttons'>
                        <form onSubmit={handleSubmit}>
                            <button className='s' type='submit'>등록</button>
                            <Link to="/postList_sje">
                                <button className='r'>취소</button>
                            </Link>
                        </form>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default CreatePost_sje;