// 필요한 React 기능과 라이브러리를 임포트합니다.
import React, { useEffect, useState } from 'react';
import axios from 'axios';  // 서버와 HTTP 통신을 위해 axios 라이브러리를 사용합니다.
import { useLocation, useHistory } from 'react-router-dom';  // URL 쿼리 문자열에 접근하기 위해 useLocation 훅을 사용합니다.
import '../css/payment_mjh.css';

// Payment 함수형 컴포넌트를 정의합니다.
function Payment_mjh() {
  // 후원 데이터를 저장할 상태 변수와 상태 설정 함수를 선언합니다.
  const [paymentData, setPaymentData] = useState({});
  // 현재 위치 정보를 저장하는 location 객체를 useLocation 훅을 사용하여 가져옵니다.
  const location = useLocation();

  // 컴포넌트 마운트 시 한 번만 실행되는 useEffect 훅입니다.
  useEffect(() => {
    const IMP = window.IMP;  // 아임포트 후원 서비스 객체를 window 전역 객체에서 가져옵니다.
    IMP.init("imp78743224");  // IMP 객체를 초기화하고 가맹점 식별코드를 설정합니다.

    // URL에서 쿼리 파라미터를 읽어들여 옵니다.
    const query = new URLSearchParams(location.search);
    // 후원 금액을 가져와서 적절히 포맷팅합니다. 1000단위로 콤마를 찍고, 끝에 '원'을 붙입니다.
    const formattedAmount = query.get('amount') ? Intl.NumberFormat('ko-KR').format(query.get('amount')) + "원" : "0원";
    // 읽어들인 쿼리 파라미터를 이용하여 paymentData 상태를 설정합니다.
    setPaymentData({
      name: query.get('name'),
      amount: formattedAmount,
      buyer_email: query.get('buyer_email'),
      buyer_name: query.get('buyer_name'),
      buyer_tel: query.get('buyer_tel'),
      buyer_addr: query.get('buyer_addr'),
      buyer_postcode: query.get('buyer_postcode')
    });
  }, [location.search]);

  const history = useHistory();
  const goBack = () => {
    history.push("/infoPayment_mjh");
  }
  // 후원 처리를 위한 함수입니다.
  const handlePayment = () => {
    const IMP = window.IMP;  // 후원 모듈 객체를 가져옵니다.
    // request_pay 함수를 호출하여 후원 프로세스를 시작합니다.
    IMP.request_pay({
      pg: "html5_inicis",  // 후원 게이트웨이를 지정합니다.
      pay_method: "card",  // 후원 방법을 지정합니다.
      merchant_uid: `merchant_${new Date().getTime()}`,  // 주문 식별번호를 생성합니다.
      ...paymentData,  // 위에서 설정한 후원 데이터를 펼칩니다.
      amount: paymentData.amount.replace(/원|,/g, ''), // 후원 금액에서 '원'과 콤마를 제거합니다.
      m_redirect_url: "/paymentSuccess"  // 후원 성공 후 리다이렉트할 URL을 지정합니다.
    }, function (rsp) {
      if (rsp.success) {
        // 후원가 성공했다면 서버에 후원 정보를 전송합니다.
        axios.post('http://localhost:9008/api/payment/process', {
          imp_uid: rsp.imp_uid,  // 후원 고유 번호
          merchant_uid: rsp.merchant_uid,  // 주문 번호
          pay_amount: rsp.paid_amount,  // 후원 금액
          apply_num: rsp.apply_num,  // 카드 승인번호
          per_time: new Date()  // 현재 시간
        }, {
          headers: { 'Content-Type': 'application/json' }  // 요청 헤더에 콘텐츠 타입을 지정합니다.
        }).then(response => {
          // 응답 성공 시 후원 성공 페이지로 이동합니다.
          window.location.href = "/paymentSuccess";
        }).catch(error => {
          // 오류 발생 시 콘솔에 오류를 출력합니다.
          console.error('후원 정보 전송 에러', error);
        });
      } else {
        // 후원 실패 시 사용자에게 실패 메시지를 알립니다.
        alert(`후원 실패: ${rsp.error_msg}`);
      }
    });
  };

  // 컴포넌트의 JSX 구조를 반환합니다.
  return (
    <div className='payment_mjh'>
      <h1>후원 정보 확인</h1>
      <div className='paymentList_mjh'>
        <label>후원</label>
        <p>{paymentData.name}</p>
        <label>후원자명</label>
        <p>{paymentData.buyer_name}</p>
        <label>후원자 이메일</label>
        <p>{paymentData.buyer_email}</p>
        <label>연락처</label>
        <p>{paymentData.buyer_tel}</p>
        <label>주소</label>
        <p>{paymentData.buyer_addr}</p>
        <label>우편번호</label>
        <p>{paymentData.buyer_postcode}</p>
        <label>후원 금액</label>
        <p>{paymentData.amount}</p>
      </div>
      <div className='donaButton_mjh'>
        <button onClick={handlePayment}>후원하기</button>
        <button onClick={goBack}>뒤로가기</button>
      </div>
    </div>
  );
}

export default Payment_mjh;  // Payment 컴포넌트를 기본으로 내보내기 설정합니다.
