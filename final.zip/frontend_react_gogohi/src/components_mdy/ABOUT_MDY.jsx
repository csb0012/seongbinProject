import React , {useEffect} from 'react';
// import { Link } from 'react-router-dom';
import AOS from "aos";
import '../css_mdy/about_mdy.css';
import "../css/aos.css";

function ABOUT_MDY() {
        useEffect (()=>{
            AOS.init({duration:2000});
        }); 

        
    return (
        <div className='container_about_mdy'>
            <div className="wrapper_about_mdy">
                <div className='about-info_mdy'>
                    <h1 data-aos="fade-up" className='tit_mdy'>하이 중학교</h1>
                    <h2 className='about_tit_mdy'>인사말</h2>
                    <div className='aboutDesc_mdy'>
                    <p>우리 하이중학교는 마음을 열고 생각을 키워 서로의 꿈을 격려하는 행복한 학교입니다.</p>
                    <p>
                    교사들은 가르치는 보람과 기쁨을 느끼고,
                    <br/>
                    학생들은 즐겁게 배우고 나눔과 성장을 통하여 꿈을 키우며, 
                    <br/>
                    학부모님은 학교에 대한 믿음과 신뢰로 교육활동에 함께 참여하여
                    <br/>
                    지역사회로부터 신뢰받는 평화와 사랑의 공동체를 만들어가고 있습니다.
                    <br/>
                    앞으로도 적극적인 지원과 성원을 부탁드립니다.
                    </p>
                    </div>
                 {/* about-info_mdy */}
                <div className='subCont_mdy'>
                 <h2 className='about_tit_mdy'>학교연혁</h2>
                    <div className='historyWrap_mdy'>
                    
                        <table className='schHiTable_mdy'>
                            <thead>
                                <tr>
                                    <th scope='col' className='Tdate_mdy'>연혁일</th>

                                    <th scope='col' className='TCont_mdy'>연혁내용</th>
                                </tr>
                            </thead>
                            <tbody>
                                 <tr>
                                    <td className="ac">2024.03.04</td>
                                    <td>제24회&nbsp;입학식(입학생&nbsp;227명)</td>
                                </tr>
                                <tr>
                                    <td className="ac">2024.01.05</td>
                                    <td>제23회&nbsp;졸업식(졸업생&nbsp;163명)</td>
                                </tr>
                                <tr>
                                    <td className="ac">2023.03.02</td>
                                    <td>제23회&nbsp;입학식(입학생&nbsp;110명)</td>
                                </tr>
                                <tr>
                                    <td className="ac">2022.12.30</td>
                                    <td>제22회&nbsp;졸업식(졸업생&nbsp;87명)</td>
                                </tr>
                                <tr>
                                    <td className="ac">2022.03.02</td>
                                    <td>제22회&nbsp;입학식(입학식&nbsp;135명)</td>
                                </tr>
                                <tr>
                                    <td className="ac">2022.01.07</td>
                                    <td>제21회&nbsp;졸업식(졸업식&nbsp;100명)</td>
                                </tr>
                                <tr>
                                    <td className="ac">2021.12.20</td>
                                    <td>학교흡연사업&nbsp;우수기관&nbsp;교육감&nbsp;표창</td>
                                </tr>
                                <tr>
                                    <td className="ac">2021.03.02</td>
                                    <td>제21회&nbsp;입학식(입학식&nbsp;159명)</td>
                                </tr>
                                <tr>
                                    <td className="ac">2021.01.08</td>
                                    <td>제20회&nbsp;졸업식(졸업식&nbsp;100명)</td>
                                </tr>
                               
                                <tr>
                                    <td className="ac">2020.03.02</td>
                                    <td>제19회&nbsp;입학식(입학식&nbsp;101명)</td>
                                </tr>
                                <tr>
                                    <td className="ac">2021.01.08</td>
                                    <td>제19회&nbsp;졸업식(졸업식&nbsp;96명)</td>
                                </tr>
                              
                                <tr>
                                    <td className="ac">2020.12.20</td>
                                    <td>방과후학교&nbsp;활성화&nbsp;우수학교&nbsp;교육감&nbsp;표창</td>
                                </tr>
                                <tr>
                                    <td className="ac">2019.12.06</td>
                                    <td>자원봉사&nbsp;프로그램&nbsp;경진대회(청소년&nbsp;부문)교육감상&nbsp;수상</td>
                                </tr>
                                	
                                <tr>
                                    <td className="ac">2018.12.21</td>
                                    <td>사교육&nbsp;없는&nbsp;학교&nbsp;운영&nbsp;우수학교&nbsp;교육감&nbsp;표창</td>
                                </tr>
                               
                                <tr  >
                                    <td className="ac">2017.12.29</td>
                                    <td>방과후학교&nbsp;운영&nbsp;우수학교&nbsp;교육감&nbsp;표창</td>
                                </tr>
                                <tr  >
                                    <td className="ac">2017.03.01</td>
                                    <td>제1회 졸업식(1학급  50명)</td>
                                </tr>
                                <tr  >
                                    <td className="ac">2016.05.04</td>
                                    <td>개교기념식</td>
                                </tr>
                                <tr  >
                                    <td className="ac">2016.03.06</td>
                                    <td>제1회 입학식(입학생 123명)</td>
                                </tr>
                                <tr  >
                                    <td className="ac">2016.01.06</td>
                                    <td>교장 취임</td>
                                </tr>
		            



                            </tbody>
                        </table>
                       




                    </div>
                    {/* historyWrap */}

                    </div>
                    {/* subcont_mdy */}

              

                {/* <p> */}
         

                {/* </p> */}

                </div> 
                {/* aboutinfo */}
            </div>
        </div>
        // wrapper 

        

    );
}

export default ABOUT_MDY;