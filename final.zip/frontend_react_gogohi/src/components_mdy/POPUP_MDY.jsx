// React 및 필요한 Hooks를 임포트합니다.
import React, { useState, useEffect, useRef } from 'react';
// 팝업 컴포넌트의 스타일 시트를 임포트합니다.
import '../css_mdy/popup_mdy.css';



const POPUP_MDY = ({ onClose }) => {

  const [checked, setChecked] = useState(false);
  const [visible, setVisible] = useState(false);
  const [position, setPosition] = useState({ x: 0, y: 0 });

  const [dragging, setDragging] = useState(false);

  const popupRef = useRef(null);


  useEffect(() => {
    setTimeout(() => {
      setVisible(true);
    }, 10);
  }, []);

  useEffect(() => {
    if (visible && popupRef.current) {
      centerPopup();
    }
  }, [visible]);

  // 팝업을 화면의 중앙에 위치시키는 함수입니다.
  const centerPopup = () => {
    // 브라우저 창의 전체 너비를 가져옵니다.
    const screenWidth = window.innerWidth;
    // 브라우저 창의 전체 높이를 가져옵니다.
    const screenHeight = window.innerHeight;
    // 팝업 요소의 너비를 가져옵니다. popupRef는 팝업 요소에 대한 참조입니다.
    const popupWidth = popupRef.current.offsetWidth;
    // 팝업 요소의 높이를 가져옵니다.
    const popupHeight = popupRef.current.offsetHeight;
    // 팝업의 위치를 계산하여 설정합니다.
    // x: 화면의 가로 너비에서 팝업의 너비를 뺀 값의 절반을 사용하여 팝업을 화면의 가로 중앙에 위치시키고,
    //    여기에 추가로 30픽셀을 더해 조금 오른쪽으로 이동시킵니다.
    // y: 화면의 세로 높이에서 팝업의 높이를 뺀 값의 절반을 사용하여 팝업을 화면의 세로 중앙에 위치시키고,
    //    여기에 추가로 30픽셀을 더해 조금 아래로 이동시킵니다.
    setPosition({
      x: (screenWidth - popupWidth) / 2 + 30,
      y: (screenHeight - popupHeight) / 2 + 30
    });
  };

  // 체크박스 상태 변경 이벤트를 처리하는 함수입니다.
  const handleCheckboxChange = (e) => {
    // 이벤트에서 체크된 상태를 가져와서 'checked' 상태를 업데이트합니다.
    setChecked(e.target.checked);

    // 만약 체크박스가 선택되었다면 추가 로직을 실행합니다.
    if (e.target.checked) {
      // 현재 날짜 및 시간을 가져옵니다.
      const now = new Date();

      // 현재 시간에 3일을 밀리초로 환산한 값을 더합니다.
      // 1일은 86400000 밀리초이므로, 3일은 259200000 밀리초입니다.
      const expirationTime = now.getTime() + 86400000;

      // 'popup-hide'라는 키로 계산된 만료 시간을 로컬 스토리지에 저장합니다.
      // 이 값은 팝업을 다시 표시하지 않기 위한 조건으로 사용될 수 있습니다.
      localStorage.setItem('popup-hide', expirationTime);
    }
  };

  // 팝업 닫기 버튼 클릭 이벤트를 처리하는 함수입니다.
  const handleClose = () => {
    setVisible(false);
    setTimeout(onClose, 300); // 부모 컴포넌트에서 제공된 onClose 콜백을 호출
  };

  // 드래그 시작 이벤트를 처리하는 함수입니다.
  const startDragging = (e) => {
    setDragging(true);
    e.preventDefault(); // 기본 이벤트를 방지
  };

  // 드래그 중 위치를 업데이트하는 이벤트를 처리하는 함수입니다.
  const onDrag = (e) => {
    if (dragging) {
      setPosition((prev) => ({
        x: prev.x + e.movementX,
        y: prev.y + e.movementY,
      }));
    }
    e.preventDefault(); // 드래그 이벤트 중 기본 이벤트를 방지
  };

  // 드래그 종료 이벤트를 처리하는 함수입니다.
  const stopDragging = () => {
    setDragging(false);
  };

  // 드래그 상태가 변경될 때 이벤트 리스너를 추가하거나 제거하는 useEffect입니다.
  useEffect(() => {
    // 'dragging' 상태가 true일 때만 실행됩니다.
    if (dragging) {
      // 사용자가 마우스를 움직일 때마다 'onDrag' 함수를 호출하는 이벤트 리스너를 윈도우 객체에 추가합니다.
      window.addEventListener('mousemove', onDrag);
      // 사용자가 마우스 버튼을 놓을 때 'stopDragging' 함수를 호출하는 이벤트 리스너를 윈도우 객체에 추가합니다.
      window.addEventListener('mouseup', stopDragging);

      // 컴포넌트가 언마운트되거나 'dragging' 상태가 false가 되기 전에 이벤트 리스너를 제거합니다.
      // 이는 성능 최적화를 위해 필수적이며, 불필요한 메모리 사용을 방지합니다.
      return () => {
        window.removeEventListener('mousemove', onDrag);
        window.removeEventListener('mouseup', stopDragging);
      };
    }
    
    // 이 useEffect는 'dragging' 상태에 따라 리-렌더링됩니다.
    // 'dragging' 상태가 변경될 때마다 이 훅이 실행되어 적절한 이벤트 리스너를 추가하거나 제거합니다.
  }, [dragging]);

  // 팝업의 JSX를 정의하며, 스타일과 이벤트 핸들러를 설정합니다.
  return (
    <div id='mdy'>
    <div className={`popup-container ${visible ? 'popup-visible' : ''}`}
         style={{ top: `${position.y}px`, left: `${position.x}px`, position: 'absolute' }}
         onMouseDown={startDragging}
         ref={popupRef}>
      <img src="resource_mdy/images/popupimage_mdy.png" alt="Special Event" style={{ width: '500%', height: '500px' }} />
  
      <div className='popup-buttons'>
      <input type="checkbox" checked={checked} onChange={handleCheckboxChange} />
        <div className='label_mdy'>
          <label>1일 동안 보지 않기</label>
        </div>
        <div className='buttonclose_mdy'>
          <button onClick={handleClose}>닫기</button>
        </div>
      </div>
    </div>
    </div>
  );
  
};

// EventPopup 컴포넌트를 다른 파일에서 사용할 수 있도록 export 합니다.
export default  POPUP_MDY;
